// Query.h
//
// Author: Ovidiu Cucu
// Homepage: http://www.codexpert.ro/
// Weblog: http://codexpert.ro/blog/

#pragma once

namespace Query 
{
    extern LPCWSTR const pszOrdersQuery; 
}